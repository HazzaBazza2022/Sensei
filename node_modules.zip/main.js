const { Client, Intents, MessageEmbed, MessageActionRow, MessageButton, MessageSelectMenu, Options, ButtonInteraction, SelectMenuInteraction } = require('discord.js');
const { SlashCommandBuilder } = require('@discordjs/builders');
const { REST, DiscordAPIError } = require('@discordjs/rest');
const { Routes, ApplicationCommandPermissionType } = require('discord-api-types/v9');

const client = new Client({ intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MESSAGES, Intents.FLAGS.GUILD_MEMBERS] });

var lookinginuse = false;
var gamename;
var gametime;
var gamechannel;
var playercount;
var gameurl;
const commands = [
    {
        name: 'report',
        description: 'Report a user',
        options: [
            {
                name: 'user',
                description: 'The user you are reporting',
                required: true,
                type: 9
            },
            {
                name: 'reason',
                description: 'The reason you are reporting this user',
                required: true,
                type: 3
            }
        ]
    },
    {
        name: 'lookingforgroup',
        description: 'Invite your friends to join you in a game'
        // options: [
        //     {
        //         name: 'game',
        //         description: 'The game you want to play',
        //         type: 2,
        //         required: true,
        //     },
        //     {
        //         name: 'time',
        //         type: 3,
        //         description: 'The time you want to play the game',
        //         required: true
        //     },
        //     {
        //         name: 'voicechannel',
        //         type: 7,
        //         description: 'The voice channel you want to use',
        //         required: true
        //     },
        //     {
        //         name: 'groupsize',
        //         type: 4,
        //         description: 'The number of people you want to play with',
        //         required: true
        //     }
        //]
    },
    {
        name: 'announce',
        description: 'Make an announcement to the server.'
    }
];

const rest = new REST({ version: '9' }).setToken('OTQ5NTIxNDg5MjY5NTAxOTgz.YiLkzA.DwUzwfSJjPlrown0HfdMDrEsG0w');

(async () => {
    try {
        console.log('Started refreshing application (/) commands.');

        await rest.put(

            Routes.applicationCommands("949521489269501983"),
            { body: commands },

        );

        console.log('Successfully reloaded application (/) commands.');
    } catch (error) {
        console.error(error);
    }
})();




client.on('ready', () => {
    console.log(`Logged in as ${client.user.tag}!`);

});

client.on(`messageCreate`, async message => {
    if(message.channel.id == `950701013369774080`)
    {
        const wrongpermissions = new MessageEmbed()
        .setColor("#FF0000")
        .setTitle("Woah, hold up")
        .setDescription(`<@${message.author.id}>, you can't send messages in \`#lookingforgroup\`, please use \`/lookingforgroup\` instead.`);
        message.author.send({ embeds: [wrongpermissions] });
        message.delete();
    }
});



client.on('interactionCreate', async interaction => {
    if (interaction.isCommand()) {
        if (interaction.commandName === 'report') {
            //const id = interaction.guild.ownerId;
            const reporteduser = interaction.options.getMentionable('user');
            const reason = interaction.options.getString('reason');
            const id = `496851397099257856`;
            const Owner = await client.users.fetch(`${id}`);
            if (!Owner) return;
            const embed = new MessageEmbed()
                .setColor("#00FF00")
                .setTitle("Report Submitted")
                .setDescription("Thank you for submitting this report, we will get back to you shortly.");
            interaction.reply({ ephemeral: true, embeds: [embed] });

            const reportembed = new MessageEmbed()
                .setColor("#FF0000")
                .setTitle("Report Received")
                .setDescription(`<@${reporteduser.id}> has been reported for \`${reason}\``);

            const row = new MessageActionRow()
                .addComponents(
                    new MessageButton()
                        .setCustomId(`timeoutbtn${reporteduser.id}`)
                        .setLabel('Timeout User')
                        .setStyle('DANGER'),
                    new MessageButton()
                        .setCustomId('ignore')
                        .setLabel('Ignore Report')
                        .setStyle('PRIMARY')
                );

            Owner.send({ embeds: [reportembed], components: [row] });

        } else if (interaction.commandName === 'lookingforgroup') {

            if (lookinginuse == true) return;
            lookinginuse = true;
            const lookingforgroup = new MessageEmbed()
                .setColor("#FFFFFF")
                .setTitle(`Looking For Group`)
                .setDescription(`<@${interaction.user.id}> please select the game you want to play, the time you want to play it, the channel the game will be in and the number of people you are looking to play with from the menus below.`);
            const row = new MessageActionRow()
                .addComponents(
                    new MessageSelectMenu()
                        .setCustomId(`gamesmenu`)
                        .setMinValues(1)
                        .setMaxValues(1)
                        .setPlaceholder(`Select a game`)
                        .addOptions([
                            {
                                label: `Fortnite`,
                                value: `fortnitegame`,
                                description: `Fortnite Battle Royale`,

                            },
                            {
                                label: `GTA 5`,
                                value: `gtagame`,
                                description: `Grand Theft Auto 5`,
                            },
                            {
                                label: `Apex Legends`,
                                value: `apexgame`,
                                description: `Apex Legends`,
                            },
                            {
                                label: `Valorant`,
                                value: `valorantgame`,
                                description: `Valorant`,
                            },
                            {
                                label: `Overwatch`,
                                value: `overwatchgame`,
                                description: `Overwatch`,
                            },
                            {
                                label: `Jackbox`,
                                value: `jackboxgame`,
                                description: `Jackbox Party Pack`,
                            }

                        ]),
                );
            const row2 = new MessageActionRow()
                .addComponents(
                    new MessageSelectMenu()
                        .setCustomId(`timemenu`)
                        .setMinValues(1)
                        .setMaxValues(1)
                        .setPlaceholder(`Select a time from now`)
                        .addOptions([
                            {
                                label: `5 Minutes`,
                                value: `5mins`,
                                description: `5 Minutes`,

                            },
                            {
                                label: `10 Minutes`,
                                value: `10mins`,
                                description: `10 Minutes`,
                            },
                            {
                                label: `20 Minutes`,
                                value: `20mins`,
                                description: `20 Minutes`,
                            },
                            {
                                label: `30 Minutes`,
                                value: `30mins`,
                                description: `30 Minutes`,
                            },
                            {
                                label: `1 Hour`,
                                value: `1hr`,
                                description: `1 Hour`,
                            },
                            {
                                label: `2 Hours`,
                                value: `2hr`,
                                description: `2 Hours`,
                            }

                        ]),
                );
            const row3 = new MessageActionRow()
                .addComponents(
                    new MessageSelectMenu()
                        .setCustomId(`channelmenu`)
                        .setMinValues(1)
                        .setMaxValues(1)
                        .setPlaceholder(`Select a channel`)
                        .addOptions([
                            {
                                label: `General 1`,
                                value: `general1`,
                                description: `General 1`,

                            },
                            {
                                label: `General 2`,
                                value: `general2`,
                                description: `General 2`,
                            },
                            {
                                label: `General 3`,
                                value: `general3`,
                                description: `General 3`,
                            }

                        ]),
                );
            const row4 = new MessageActionRow()
                .addComponents(
                    new MessageSelectMenu()
                        .setCustomId(`playermenu`)
                        .setMinValues(1)
                        .setMaxValues(1)
                        .setPlaceholder(`Select number of players`)
                        .addOptions([
                            {
                                label: `1`,
                                value: `oneplayer`,
                                description: `One Player`,

                            },
                            {
                                label: `2`,
                                value: `twoplayer`,
                                description: `Two Players`,
                            },
                            {
                                label: `3`,
                                value: `threeplayer`,
                                description: `Three Players`,
                            },
                            {
                                label: `4`,
                                value: `fourplayer`,
                                description: `Four players`,
                            },
                            {
                                label: `5+`,
                                value: `fiveplus`,
                                description: `Five players or more`,
                            }

                        ]),
                );
            const row5 = new MessageActionRow()
                .addComponents(
                    new MessageButton()
                        .setCustomId(`confirmgroup`)
                        .setLabel(`Confirm`)
                        .setStyle(`PRIMARY`),
                    new MessageButton()
                        .setCustomId(`cancelgroup`)
                        .setLabel(`Cancel`)
                        .setStyle(`SECONDARY`)
                );
            interaction.reply({ embeds: [lookingforgroup], ephemeral: true, components: [row, row2, row3, row4, row5] });
        }
    } else if (interaction.isButton()) {
        if (interaction.customId == "ignore") {
            const row = new MessageActionRow()
                .addComponents(
                    new MessageButton()
                        .setCustomId('timeout')
                        .setLabel('Timeout User')
                        .setStyle('DANGER')
                        .setDisabled(true),
                    new MessageButton()
                        .setCustomId('ignore')
                        .setLabel('Ignore Report')
                        .setStyle('PRIMARY')
                        .setDisabled(true)

                );
            const reportembed = new MessageEmbed()
                .setColor("#474f98")
                .setTitle("Report Ignored")
                .setDescription(`This report has been ignored, no further action from you is required at this time.`);
            interaction.update({ components: [row], embeds: [reportembed] });
        } else if (interaction.customId.startsWith("timeoutbtn")) {
            const userid = interaction.customId.substring(10);
            const reportguild = client.guilds.cache.first();
            const reporteduser = reportguild.members.cache.get(`${userid}`);


            const timeoutembed = new MessageEmbed()
                .setColor("#FF0000")
                .setTitle("Timeout User")
                .setDescription(`How long would you like to timeout <@${userid}> for?`);

            const row = new MessageActionRow()
                .addComponents(
                    new MessageButton()
                        .setCustomId(`settimeout5<${userid}>`)
                        .setLabel('5 Minutes')
                        .setStyle('PRIMARY'),
                    new MessageButton()
                        .setCustomId(`settimeout10<${userid}>`)
                        .setLabel('10 Minutes')
                        .setStyle('PRIMARY'),
                    new MessageButton()
                        .setCustomId(`settimeout1hr<${userid}>`)
                        .setLabel('1 Hour')
                        .setStyle('PRIMARY')
                );
            const row2 = new MessageActionRow()
                .addComponents(
                    new MessageButton()
                        .setCustomId(`settimeout1d<${userid}>`)
                        .setLabel('1 Day')
                        .setStyle('PRIMARY'),
                    new MessageButton()
                        .setCustomId(`settimeout1w<${userid}>`)
                        .setLabel('1 Week')
                        .setStyle('PRIMARY'),
                    new MessageButton()
                        .setCustomId(`cancel`)
                        .setLabel('Cancel')
                        .setStyle('SECONDARY')
                );

            interaction.update({ embeds: [timeoutembed], components: [row, row2] });

        } else if (interaction.customId == "cancel") {
            const row = new MessageActionRow()
                .addComponents(
                    new MessageButton()
                        .setCustomId(`timeout5`)
                        .setLabel('5 Minutes')
                        .setStyle('PRIMARY')
                        .setDisabled(true),
                    new MessageButton()
                        .setCustomId(`timeout10`)
                        .setLabel('10 Minutes')
                        .setStyle('PRIMARY')
                        .setDisabled(true),
                    new MessageButton()
                        .setCustomId(`timeout1hr`)
                        .setLabel('1 Hour')
                        .setStyle('PRIMARY')
                        .setDisabled(true)
                );
            const row2 = new MessageActionRow()
                .addComponents(
                    new MessageButton()
                        .setCustomId(`timeout1d`)
                        .setLabel('1 Day')
                        .setStyle('PRIMARY')
                        .setDisabled(true),
                    new MessageButton()
                        .setCustomId(`timeout1w`)
                        .setLabel('1 Week')
                        .setStyle('PRIMARY')
                        .setDisabled(true),
                    new MessageButton()
                        .setCustomId(`endinteraction`)
                        .setLabel('Cancel')
                        .setStyle('SECONDARY')
                        .setDisabled(true)
                );
            const cancelembed = new MessageEmbed()
                .setColor("#474f98")
                .setTitle("Timeout Canceled")
                .setDescription(`The timeout has been canceled, no further action is required from you at this time.`);
            interaction.update({ components: [row, row2], embeds: [cancelembed] });
        } else if (interaction.customId.startsWith("settimeout")) {
            const userid1 = interaction.customId.substring(interaction.customId.indexOf("<"), interaction.customId.indexOf(">"));
            const userid = userid1.substring(1);
            const reportguild = client.guilds.cache.first();
            const reporteduser = reportguild.members.fetch(`${userid}`);

            const timeoutlen1 = interaction.customId.substring(0, interaction.customId.indexOf("<"));
            const timeoutlen2 = timeoutlen1.substring(10);
            var timeoutlenembed;
            if (timeoutlen2 == "5") {
                timeoutlenembed = "5 minutes.";
                (await reporteduser).timeout(300000);
            } else if (timeoutlen2 == "10") {
                (await reporteduser).timeout(10 * 60 * 1000);
                timeoutlenembed = "10 minutes.";
            } else if (timeoutlen2 == "1hr") {
                (await reporteduser).timeout(60 * 60 * 1000);
                timeoutlenembed = "1 hour.";
            } else if (timeoutlen2 == "1d") {
                (await reporteduser).timeout(1440 * 60 * 1000);
                timeoutlenembed = "1 day.";
            } else if (timeoutlen2 == "1w") {
                (await reporteduser).timeout(10080 * 60 * 1000);
                timeoutlenembed = "1 week.";
            }

            const row = new MessageActionRow()
                .addComponents(
                    new MessageButton()
                        .setCustomId(`timeout5`)
                        .setLabel('5 Minutes')
                        .setStyle('PRIMARY')
                        .setDisabled(true),
                    new MessageButton()
                        .setCustomId(`timeout10`)
                        .setLabel('10 Minutes')
                        .setStyle('PRIMARY')
                        .setDisabled(true),
                    new MessageButton()
                        .setCustomId(`timeout1hr`)
                        .setLabel('1 Hour')
                        .setStyle('PRIMARY')
                        .setDisabled(true)
                );
            const row2 = new MessageActionRow()
                .addComponents(
                    new MessageButton()
                        .setCustomId(`timeout1d`)
                        .setLabel('1 Day')
                        .setStyle('PRIMARY')
                        .setDisabled(true),
                    new MessageButton()
                        .setCustomId(`timeout1w`)
                        .setLabel('1 Week')
                        .setStyle('PRIMARY')
                        .setDisabled(true),
                    new MessageButton()
                        .setCustomId(`cancel`)
                        .setLabel('Cancel')
                        .setStyle('SECONDARY')
                        .setDisabled(true)
                );
            const timeoutsuccessembed = new MessageEmbed()
                .setColor("#474f98")
                .setTitle("Timeout Given")
                .setDescription(`<@${userid}> has successfully been timed out for \`${timeoutlenembed}\``);
            interaction.update({ components: [row, row2], embeds: [timeoutsuccessembed] });
        } else if (interaction.customId === `cancelgroup`) {
            const row = new MessageActionRow()
                .addComponents(
                    new MessageButton()
                        .setCustomId(`confirmgroup`)
                        .setLabel(`Confirm`)
                        .setDisabled(true)
                        .setStyle(`PRIMARY`),
                    new MessageButton()
                        .setCustomId(`cancelgroup`)
                        .setDisabled(true)
                        .setLabel(`Cancel`)
                        .setStyle(`SECONDARY`)
                );

            const lookingforgroup = new MessageEmbed()
                .setColor("#FFFFFF")
                .setTitle(`Looking For Group Canceled`)
                .setDescription(`This interaction has been canceled, no further action is required at this time.`);
            await interaction.update({ embeds: [lookingforgroup], components: [row] });
            lookinginuse = false;
        } else if (interaction.customId === `confirmgroup`) {
            const row = new MessageActionRow()
                .addComponents(
                    new MessageButton()
                        .setCustomId(`confirmgroup`)
                        .setLabel(`Confirm`)
                        .setDisabled(true)
                        .setStyle(`PRIMARY`),
                    new MessageButton()
                        .setCustomId(`cancelgroup`)
                        .setDisabled(true)
                        .setLabel(`Cancel`)
                        .setStyle(`SECONDARY`)
                );
            const lookingforgroup = new MessageEmbed()
                .setColor("#FFFFFF")
                .setTitle(`Looking For Group Confirmed`)
                .setDescription(`This interaction has been confirmed, no further action is required at this time.`);
            await interaction.update({ embeds: [lookingforgroup], components: [row] });

            const lookingforgroupembed = new MessageEmbed()
                .setColor("#FFFFFF")
                .setTitle(`Looking For Group - ${gamename}`)
                .setDescription(`<@${interaction.user.id}> is looking for a group to play \`${gamename}\``)
                .addField("Game", `${gamename}`, true)
                .addField("Time", `${gametime} from now`, true)
                .addField("Channel", `${gamechannel}`, true)
                .addField("Group Size", `${playercount}`, true)

                .setThumbnail(gameurl);
            await interaction.channel.send({ embeds: [lookingforgroupembed] });
            lookinginuse = false;
        }
    } else if (interaction.isSelectMenu()) {
        if (interaction.customId === `gamesmenu`) {
            await interaction.deferUpdate();
            const gamenameraw = interaction.values[0];
            if (gamenameraw == "fortnitegame") {
                gamename = "Fortnite";
                gameurl = "https://cdn2.unrealengine.com/12br-delay-social-news-header-02-1920x1080-119208936.jpg";
            } else if (gamenameraw == "apexgame") {
                gamename = "Apex Legends";
                gameurl = "https://wallpaperaccess.com/full/3813466.jpg";
            } else if (gamenameraw == "gtagame") {
                gamename = "GTA 5";
                gameurl = "https://i.pinimg.com/originals/9a/77/db/9a77db0d3793bb8c4170658776d948c8.jpg";
            }
            else if (gamenameraw == "overwatchgame") {
                gamename = "Overwatch";
                gameurl = "https://external-preview.redd.it/5Ow3RDQQGkwzzFC60j5_PjFPQ2hd11E2etWQIb3WcRE.jpg?auto=webp&s=191b7cfe6531fca11c8c72bd77074c9b7e850946";
            }
            else if (gamenameraw == "valorantgame") {
                gamename = "Valorant";
                gameurl = "https://wallpaperaccess.com/full/4547484.jpg";
            }
            else if (gamenameraw == "jackboxgame") {
                gamename = "Jackbox Party Pack";
                gameurl = "https://jackboxgames.b-cdn.net/wp-content/uploads/2020/05/pp1Logo.png";
            }

        } else if (interaction.customId === `timemenu`) {
            await interaction.deferUpdate();
            const gamenameraw = interaction.values[0];
            if (gamenameraw == "5mins") {
                gametime = "5 Minutes";
            } else if (gamenameraw == "10mins") {
                gametime = "10 Minutes";
            } else if (gamenameraw == "20mins") {
                gametime = "20 Minutes";
            }
            else if (gamenameraw == "30mins") {
                gametime = "30 Minutes";
            }
            else if (gamenameraw == "1hr") {
                gametime = "1 Hour";
            }
            else if (gamenameraw == "2hr") {
                gametime = "2 Hours";
            }
        } else if (interaction.customId === `channelmenu`) {
            await interaction.deferUpdate();
            const gamenameraw = interaction.values[0];
            if (gamenameraw == "general1") {
                gamechannel = "General 1";
            } else if (gamenameraw == "general2") {
                gamechannel = "General 2";
            } else if (gamenameraw == "general3") {
                gamechannel = "General 3";
            }

        }
        else if (interaction.customId === `playermenu`) {
            await interaction.deferUpdate();
            const gamenameraw = interaction.values[0];
            if (gamenameraw == "oneplayer") {
                playercount = "1";
            } else if (gamenameraw == "twoplayer") {
                playercount = "2";
            } else if (gamenameraw == "threeplayer") {
                playercount = "3";
            } else if (gamenameraw == "fourplayer") {
                playercount = "4";
            } else if (gamenameraw == "fiveplus") {
                playercount = "5+";
            }
        }

    }

});

client.login('OTQ5NTIxNDg5MjY5NTAxOTgz.YiLkzA.DwUzwfSJjPlrown0HfdMDrEsG0w');